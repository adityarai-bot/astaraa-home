<p align="center">
  <img src="https://i.discord.fr/PSS.png">
</p>

<h1 align="center">[Discord] - All Tools In One (V2.0)</h1>
<p align="center">
  <a href="https://github.com/AstraaDev/Discord-All-Tools-In-One/blob/main/LICENSE">
    <img src="https://img.shields.io/badge/License-MIT-important">
  </a>
  <a href="https://www.python.org">
    <img src="https://img.shields.io/badge/Python-3.9-informational.svg">
  </a>
  <a href="https://github.com/AstraaDev/Discord-All-Tools-In-One">
    <img src="https://img.shields.io/badge/covarage-90%25-yellowgreen">
  </a>
  <a href="https://github.com/AstraaDev">
    <img src="https://img.shields.io/github/repo-size/AstraaDev/Discord-All-Tools-In-One.svg?label=Repo%20size&style=flat-square">
  </a>
  <a href="https://github.com/AstraaDev">
    <img src="https://gpvc.arturio.dev/AstraaDev">
  </a>
    <p align="center"> <a href="https://twitter.com/astraadev" target="blank">
    <img src="https://img.shields.io/twitter/follow/astraadev?logo=twitter&style=for-the-badge" alt="astraadev"/></a>
  </a>
</p>

<p align="center">
  [Discord] - All Tools In One is a Script Gathering for Windows/MacOS/Linux systems written in Python.
</p>

## Disclaimer
<p align="center">
   This project was created only for good purposes and personal use.
</p>

THIS SOFTWARE IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND. YOU MAY USE THIS SOFTWARE AT YOUR OWN RISK. THE USE IS COMPLETE RESPONSIBILITY OF THE END-USER. THE DEVELOPERS ASSUME NO LIABILITY AND ARE NOT RESPONSIBLE FOR ANY MISUSE OR DAMAGE CAUSED BY THIS PROGRAM.

## Features
- [x] - [RAT Tool](https://github.com/moom825/Discord-RAT) - Create a RAT file. Once the victim runs it, you can control his PC through a BOT Discord.
- [x] - [Raid Tool](https://github.com/zetism/AveryNuker) - Easily raid a discord server with a BOT Discord.
- [x] - [VideoCrash Maker](https://github.com/AstraaDev/Discord-VideoCrashMaker) - Convert a video into an identical video that makes Crash discord app when played.
- [x] - [Massive Report]() - Loop that reports the message of a user (it can ban his account).
- [x] - [WebHooks Spammer]() - Spam the message you want through a WebHooks.
- [x] - [Token Grabber](https://github.com/AstraaDev/Discord-Token-Grabber) - Creates a TokenGrabber.py file to get a user's token and allows you to convert it to an Exe.
- [x] - [Token Qr Generator](https://github.com/AstraaDev/Discord-Qr-Code-Token) - Generate a "Fake Nitro QR Code". If a user scans it, you get his token.
- [x] - [Token BrutForce]() - BrutForce the token of a target user by its ID (the process can be long).
- [x] - [Token Rape]() - Quit the servers, Delete friends and DMs, change the settings of a user with his Token. 
- [x] - [Token Informations]() - Get all the information of a Discord User with his Token.
- [x] - [AutoLogin](https://github.com/AstraaDev/Discord-Token-AutoLogin) - Enter a user's token and automatically log in to the user's account.
- [x] - [Nitro Generator]() - Generates and tests a Nitro code. If it works, you will be notified.
- [x] - [Token Generator]() - Generate and test a Discord Token. If it works, you will be notified.
- [x] - [HypeSquad House Changer]() - Select your HypeSquad House.
- [x] - [Cycle ColorTheme]() - Cycle the color of the Discord theme (Black/White) of a user with his Token.
- [x] - [WebHooks Remover]() - Delete any WebHooks link.

## How To Install

### -Automated installation:

ㅤ● Launch the [setup.bat](setup.bat) file. A new file will be created. You will only have to launch it.
ㅤ

ㅤ

### OR
ㅤ


### -Manual installation:

ㅤ● Clone the repository.
```
ㅤ$ git clone https://github.com/AstraaDev/Discord-All-Tools-In-One.git
```

ㅤ● Install Modules.
```
ㅤ$ python -m pip install -r requirements.txt
```

ㅤ● Run.
```
ㅤ$ python astraahome.py
```

## Additional Informations
General Informations:
- If you have a problem, [CLICK HERE](https://www.youtube.com/watch?v=27-Swg_MUNw&t=16s) to watch the YouTube video.
- Find your output files in the  [temp](/temp) folder.
- If you find any malfunction, contact me on Discord: Astraa#4589.

Script Informations:
- For the operation of the RAT Tool, please refer to the [creator's page](https://github.com/moom825/Discord-RAT).
- For the operation of the VideoCrash Maker, please refer to [this page](https://github.com/AstraaDev/Discord-VideoCrashMaker).

## Example
![home.png](https://cdn.discordapp.com/attachments/826581697436581919/897160907879231498/unknown.png)

## Credits
[<img src='https://cdn.jsdelivr.net/npm/simple-icons@3.0.1/icons/github.svg' alt='github' height='25'>](https://github.com/AstraaDev)          [<img src='https://cdn.jsdelivr.net/npm/simple-icons@3.0.1/icons/twitter.svg' alt='twitter' height='25'>](https://twitter.com/AstraaDev)          [<img src='https://cdn.jsdelivr.net/npm/simple-icons@3.0.1/icons/icloud.svg' alt='website' height='25'>](http://astraadev.club)  
<br>
[![Astraa's GitHub stats](https://github-readme-stats.vercel.app/api?username=AstraaDev)](https://github.com/AstraaDev/github-readme-stats)

## Support
Support this project and [others](https://github.com/AstraaDev) by Astraa via [PayPal](https://www.paypal.com/).
<br>
<br>
<a href="https://www.paypal.me/fmrhrt/">
  <img alt="Support via PayPal" src="https://cdn.rawgit.com/twolfson/paypal-github-button/1.0.0/dist/button.svg"/>
</a>
